#!/usr/bin/env python3
"""
GTA 6 DualSense Restock Checker
--------------------------------
Pensato per essere eseguito periodicamente da GitHub Actions (una singola
"passata" ad ogni run, non un loop infinito: e' il workflow a schedularlo).

Legge TELEGRAM_TOKEN e TELEGRAM_CHAT_ID dalle variabili d'ambiente
(impostate come GitHub Secrets), controlla i prodotti in PRODUCTS e manda
un messaggio Telegram se uno di questi risulta tornato disponibile
rispetto all'ultimo controllo (stato salvato in stock_state.json,
che il workflow ricommitta nel repo per mantenerlo tra un run e l'altro).
"""

import os
import json
import sys
import requests
from bs4 import BeautifulSoup

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")

# Modifica questa lista con gli URL diretti dei prodotti da monitorare.
PRODUCTS = [
    {
        "name": "GTA 6 DualSense Black - PlayStation Direct",
        "url": "https://direct.playstation.com/it-it/",  # <-- sostituisci con URL diretto
        "in_stock_keywords": ["aggiungi al carrello", "add to cart"],
        "out_of_stock_keywords": ["esaurito", "sold out", "out of stock", "non disponibile"],
    },
    {
        "name": "GTA 6 DualSense White - Amazon",
        "url": "https://www.amazon.it/",  # <-- sostituisci con URL diretto
        "in_stock_keywords": ["aggiungi al carrello", "add to cart"],
        "out_of_stock_keywords": ["attualmente non disponibile", "currently unavailable"],
    },
]

STATE_FILE = "stock_state.json"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": text, "disable_web_page_preview": False}
    r = requests.post(url, data=payload, timeout=10)
    r.raise_for_status()


def check_stock(product):
    try:
        resp = requests.get(product["url"], headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"[ERRORE] Impossibile caricare {product['name']}: {e}")
        return None

    text = BeautifulSoup(resp.text, "html.parser").get_text(separator=" ").lower()

    if any(k in text for k in product["out_of_stock_keywords"]):
        return False
    if any(k in text for k in product["in_stock_keywords"]):
        return True
    return None


def main():
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("TELEGRAM_TOKEN o TELEGRAM_CHAT_ID mancanti (controlla i GitHub Secrets).")
        sys.exit(1)

    state = load_state()

    for product in PRODUCTS:
        name = product["name"]
        available = check_stock(product)
        was_available = state.get(name, False)

        print(f"{name}: disponibile={available}")

        if available is True and not was_available:
            send_telegram_message(f"🚨 RESTOCK! {name} è tornato disponibile!\n{product['url']}")

        if available is not None:
            state[name] = available

    save_state(state)


if __name__ == "__main__":
    main()
